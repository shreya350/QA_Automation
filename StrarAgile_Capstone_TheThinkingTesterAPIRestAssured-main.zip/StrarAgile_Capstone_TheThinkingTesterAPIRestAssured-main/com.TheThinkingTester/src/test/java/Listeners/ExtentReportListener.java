package Listeners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class ExtentReportListener implements ITestListener{
	
	private static ExtentSparkReporter htmlReport;
	private static ExtentReports report;
	private static ThreadLocal<ExtentTest> test = new ThreadLocal<>();
	
	@Override
	public void onStart(ITestContext context)
	{
		htmlReport = new ExtentSparkReporter("TheThinkingTester.html");
		report = new ExtentReports();
		report.attachReporter(htmlReport);
		
		report.setSystemInfo("ProjectName", "TheThinkingTester");
		report.setSystemInfo("Machine", "Windows");
		report.setSystemInfo("Company", "Star Agile");
		report.setSystemInfo("User", "Automation user");
		report.setSystemInfo("API Type", "RestAssured");
		report.setSystemInfo("FrameWork", "Selenium Webdriver,TestNG,RestAssured,ExtentReport");

		// configuration to report
		htmlReport.config().setDocumentTitle("My simple Extent Report");
		htmlReport.config().setReportName("TheThinkingTester Report");
		htmlReport.config().setTheme(Theme.STANDARD);
		htmlReport.config().setTimeStampFormat("dd-MM-YYYY");
	}

	@Override
	public void onTestStart(ITestResult result)
	{
		if(report==null) return;
		
		ExtentTest node = report.createTest(result.getMethod().getMethodName());
		test.set(node);
	}
	
	@Override
	public void onTestSuccess(ITestResult result)
	{
		ExtentTest t = test.get();
		if(t != null)
		{
			t.pass("Test Passed");
		}
	}
	
	@Override
	public void onTestFailure(ITestResult result)
	{
		ExtentTest t = test.get();
		if(t != null)
		{
			t.fail("Test Failed"+result.getThrowable());
		}
	}
	
	@Override
	public void onFinish(ITestContext context)
	{
		if(report!=null)
		{
			report.flush();
		}
	}
}



