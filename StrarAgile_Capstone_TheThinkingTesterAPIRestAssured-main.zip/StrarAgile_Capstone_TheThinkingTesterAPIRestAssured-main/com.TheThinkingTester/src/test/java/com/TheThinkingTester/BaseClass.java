package com.TheThinkingTester;

import org.testng.annotations.BeforeTest;

import io.restassured.RestAssured;
//import static io.restassured.matcher.RestAssuredMatchers.*;
//import static org.hamcrest.Matchers.*;


public class BaseClass {
	
	@BeforeTest
	public void setup()
	{
	RestAssured.baseURI = "https://thinking-tester-contact-list.herokuapp.com";
	
	/*RequestSpecification reqSpec = new RequestSpecBuilder()
			.setBaseUri(RestAssured.baseURI)
			.setContentType(ContentType.JSON)
			.build();
	*/		
	}
	
	
}