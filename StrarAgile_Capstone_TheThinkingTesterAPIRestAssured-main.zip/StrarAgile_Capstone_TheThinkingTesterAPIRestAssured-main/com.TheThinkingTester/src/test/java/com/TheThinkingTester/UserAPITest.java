package com.TheThinkingTester;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.containsString;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Listeners.ExtentReportListener;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

@Listeners(ExtentReportListener.class)
public class UserAPITest extends BaseClass{
	
	public static String authToken = null;
	public static String userId = null;
	public static List<String> contactIds = new ArrayList<>();
	
	@Test
	public void TC_01_AddNewUser()
	{
		Response response =given()
								.header("Content-Type",ContentType.JSON)
								.body("{ \"firstName\": \"vikranth\",\"lastName\": \"manoharan\","
										+ "\"email\": \"vikranthr2378019935@yopmail.com\","
										+ "\"password\": \"mypassword\"	}")
							.when()
								.post("/users")
							.then()
								.statusCode(201)
								.statusLine(containsString("Created"))
								.log().body()
							.extract().response();
		
		String token = response.jsonPath().getString("token");
		String userId = response.jsonPath().getString("user._id");
		
		authToken = token;
		System.out.println(authToken);
		System.out.println(userId);
		
		int statusCode = response.getStatusCode();
		Assert.assertTrue(statusCode==201, "Status Code Mismatch !");
	}
	
	@Test(dependsOnMethods="TC_01_AddNewUser")
	public void TC_02_GetUserProfile()
	{
		
		Response response = given()
								.auth().oauth2(authToken)
								.header("Content-Type",ContentType.JSON)
							.when()
								.get("/users/me")
							.then()
								.statusCode(200)
								.statusLine(containsString("OK"))
								.log().body()
							.extract().response();	
		
		int statusCode = response.getStatusCode();
		Assert.assertTrue(statusCode==200,"Status Code Mismatch !");
						
	}
	
	@Test(dependsOnMethods="TC_01_AddNewUser")
	public void TC_03UpadateUser()
	{
		Response response = given()
								.auth().oauth2(authToken)
								.header("Content-Type",ContentType.JSON)
								.body("{ \"firstName\": \"vikranthNew\",\"lastName\": \"manoharan\","
										+ "\"email\": \"vikranthr2378019935@yopmail.com\","
										+ "\"password\": \"mypassword\" }")
							.when()
								.patch("/users/me")
							.then()
								.statusCode(200)
								.statusLine(containsString("OK"))
							.extract().response();
		
		String authToken = response.jsonPath().getString("token");
		int statusCode = response.getStatusCode();
		Assert.assertTrue(statusCode==200, "Status Code Mismatch");
		
	}
	
	@Test(dependsOnMethods="TC_01_AddNewUser")
	public void TC_04_LogInUser()
	{
		Response response = given()
								.auth().oauth2(authToken)
								.contentType(ContentType.JSON)
								.body("{ \"email\": \"vikranthr2378019935@yopmail.com\",\"password\": \"mypassword\" }")
							.when()
								.post("/users/login")
							.then()
								.statusCode(200)
								.statusLine(containsString("OK"))
							.extract().response();
		String authToken = response.jsonPath().getString("token");
		int statusCode = response.getStatusCode();
		Assert.assertTrue(statusCode==200, "Status Code Mismatch !");		
	}
	
	@Test(dependsOnMethods="TC_01_AddNewUser")
	public void TC_05_AddContact()
	{
		Response response = given()
								.auth().oauth2(authToken)
								.contentType(ContentType.JSON)
								.body("{ \"firstName\": \"Jothika\",\"lastName\": \"Vikranth\","
									+"\"birthdate\": \"2025-01-01\",\"email\": \"Jothika1829@yopmail.com\", \"phone\": \"99999888888\","
									+"\"street1\": \"12 Main St.\", \"street2\": \"Apartment B\", \"city\": \"Chennai\","
									+"\"stateProvince\": \"TN\", \"postalCode\": \"666845\", \"country\": \"India\" }")	
							.when()
								.post("/contacts")
							.then()
								.statusCode(201)
								.statusLine(containsString("Created"))
							.extract().response();
		String authToken = response.jsonPath().getString("token");
		int statusCode = response.getStatusCode();
		Assert.assertTrue(statusCode==201, "Status Code Mismatch !");
	}
	
	@Test(dependsOnMethods="TC_05_AddContact")
	public void TC_06_GetContactList()
	{
		Response response = given()
								.auth().oauth2(authToken)
								.contentType(ContentType.JSON)
							.when()
								.get("/contacts")
							.then()
								.statusCode(200)
								.statusLine(containsString("OK"))
								.log().body()
							.extract().response();
		
		System.out.println(response.body());
		List<String> contactIds = response.jsonPath().getList("_id"); 
		
		UserAPITest.contactIds = contactIds;
		System.out.println(contactIds);
		int statusCode = response.getStatusCode();
		Assert.assertTrue(statusCode==200, "Status Code Mismatch !");
	}
	
	@Test(dependsOnMethods="TC_06_GetContactList")
	public void TC_07_GetContact()
	{
		String secondId = UserAPITest.contactIds.get(0);
		Response response = given()
								.auth().oauth2(authToken)
								.contentType(ContentType.JSON)
							.when()
								.get("/contacts/" + secondId)
							.then()
								.statusCode(200)
								.statusLine(containsString("OK"))
							.extract().response();
		
		String authToken = response.jsonPath().getString("token");
		int statusCode = response.getStatusCode();
		Assert.assertTrue(statusCode==200, "Status Code Mismatch !");
	}
	
	@Test(dependsOnMethods="TC_06_GetContactList")
	public static void TC_08_UpdateContact()
	{
		String firstid = UserAPITest.contactIds.get(0);
		String updateEmail = "jothika1829@yopmail.com";
		Response response = given()
								.auth().oauth2(authToken)
								.contentType(ContentType.JSON)
								.body("{ \"firstName\": \"JothikaUpdated\",\"lastName\": \"VikranthUpdated\","
                                       +"\"birthdate\": \"2020-02-02\","
                                       +"\"email\": \"" +updateEmail+ "\",\"phone\": \"999955555\","
                                       +"\"street1\": \"13 School St.\",\"street2\": \"2nd street\","
                                       +"\"city\": \"Trichy\",\"stateProvince\": \"TN\","
                                       +"\"postalCode\": \"666666\",\"country\": \"India\"} ")
							.when()
								.put("/contacts/"+firstid)
							.then()
								.statusCode(200)
							.extract().response();
		
		String token = response.jsonPath().getString("token");
		int statusCode = response.getStatusCode();
		Assert.assertTrue(statusCode==200, "Status Code Mismatch !");
		String expectedEmail = response.jsonPath().getString("email");
		Assert.assertTrue(updateEmail.equals(expectedEmail));
	}	
	
	@Test(dependsOnMethods="TC_06_GetContactList")
	public void TC_09_UpdateContactSingleValue()
	{
		String firstid = UserAPITest.contactIds.get(0);
		String updatedName = "JothikaNewUpdated";
		Response response = given()
								.auth().oauth2(authToken)
								.contentType(ContentType.JSON)
								.body("{ \"firstName\": \"" + updatedName + "\" }")
							.when()
								.patch("/contacts/"+firstid)
							.then()
								.statusCode(200)
							.extract().response();
				
		String token = response.jsonPath().getString("token");

		String expectedfirstName = response.jsonPath().getString("firstName");
		Assert.assertTrue(updatedName.equals(expectedfirstName));
	}
	
	@Test(dependsOnMethods="TC_09_UpdateContactSingleValue")
	public void TC_10_LogoutUser()
	{
		
		Response response = given()
								.auth().oauth2(authToken)
								.contentType(ContentType.JSON)
							.when()
								.post("/users/logout")
							.then()
								.statusCode(200)
							.extract().response();
		int statusCode = response.getStatusCode();
		
		Assert.assertTrue(statusCode==200,"Status Code Mismatch !");
	}

}
